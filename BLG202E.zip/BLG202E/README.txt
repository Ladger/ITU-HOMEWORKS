When you try to run the code from prompt. Please be careful about the file paths
The output will occur where path of the main.py stands